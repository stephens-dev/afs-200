PI = 3.14
r = float(input("Enter the radius of a circle:"))
area = PI * r * r
print("The are of your circle is %.2f" %area)