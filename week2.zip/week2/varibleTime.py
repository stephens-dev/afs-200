failed='english and history'
student1='johnny boy'
student2='little pepito'

print(student1,'is failing ',failed,'classes')
print(student1,'will need to retake',failed)
print('However',student2,'has aced spanish')