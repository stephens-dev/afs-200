p=input('give a string' )
print(p.upper())

# class Dog:
#     v=input('please give a string')

#     def help(self):
#         print('I am lost',self.v)


#     que = Dog()


# print(que.v)
# que.help()