a = int(input('First number'))
b = int(input('Second number'))

x = lambda a,b : a * b

print(x(a,b))