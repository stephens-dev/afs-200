city = input('What city are you located in: ')
zip = input('What is your zip code: ')

print ('You live at',city,zip)