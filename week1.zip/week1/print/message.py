print ('I love python')

print ('I like python' , 'javascript')

a = 'Python'

b = 'Javascript'

print ('I enjoy' ,a ,'and', b)