name = input('What is your name: ')
age = input('How old are you: ')

year = 2021

# def final(): 
#     return year - int(age) + 100 
    
final = int(year) - int(age) + 100

print ('You will be 100 in the year',final)